package hotel;

import hs.res.*;
import hs.db.*;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class VidmotHerbergi extends javax.swing.JFrame {

    private ArrayList<Room> rooms;
    private Hotel hotel;
    private VidmotHotels vidmotHotels;
    private JTable table;

    /**
     * Creates new form VidmotHerbergi
     */
    public VidmotHerbergi(Hotel hotel, VidmotHotels vidmotHotels, Date checkIn,Date checkOut) {
        this.rooms = hotel.getRooms();
        this.hotel = hotel;
        this.vidmotHotels = vidmotHotels;
        initComponents();
        teiknaListaAfHerbergjum();
        teiknaHaus();
    }

    public void teiknaHaus() {
        jHausTxt.setText("Laus herbergi á " + hotel.getName());
    }

    public void teiknaListaAfHerbergjum() {
        int n = rooms.size();
        Object[][] roomsObj = new Object[n][2];
        for (int i = 0; i < n; i++) {
            roomsObj[i][0] = rooms.get(i).getRoomType();
            roomsObj[i][1] = "" + rooms.get(i).getPrice() + "kr";
        }

        DefaultTableModel tableModel = new DefaultTableModel();
        JTable newtable = new JTable(tableModel);
        newtable.setRowHeight(50);
        tableModel.addColumn("Týpa af herbergi");
        tableModel.addColumn("Verð fyrir eina nótt");

        for (int i = 0; i < n; i++) {
            tableModel.insertRow(i, roomsObj[i]);
        }
        JPanel jPanel = new JPanel();
        jPanel.setSize(jPanelListiHerb.getSize());

        Color ivory = new Color(121, 155, 161);
        newtable.setOpaque(true);
        newtable.setFillsViewportHeight(true);
        newtable.setBackground(ivory);


        jPanel.add(new JScrollPane(newtable));
        jPanel.setVisible(true);
        jPanel.setBackground(Color.decode("#DFFAFF"));
        newtable.getTableHeader().setBackground(ivory);

        this.table = newtable;
        jPanelListiHerb.add(jPanel);
        jPanelListiHerb.setVisible(true);
        
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jHausTxt = new javax.swing.JLabel();
        jBackButton = new javax.swing.JButton();
        jPanelListiHerb = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(173, 216, 230));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, null, new java.awt.Color(121, 155, 161)));

        jHausTxt.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jHausTxt.setText("Laus herbergi á (hotel..)");

        jBackButton.setBackground(new java.awt.Color(255, 255, 255));
        jBackButton.setText("Back");
        jBackButton.setBorder(null);
        jBackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBackButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jBackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 121, Short.MAX_VALUE)
                .addComponent(jHausTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 576, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(97, 97, 97))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jHausTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jBackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(52, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanelListiHerbLayout = new javax.swing.GroupLayout(jPanelListiHerb);
        jPanelListiHerb.setLayout(jPanelListiHerbLayout);
        jPanelListiHerbLayout.setHorizontalGroup(
            jPanelListiHerbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 630, Short.MAX_VALUE)
        );
        jPanelListiHerbLayout.setVerticalGroup(
            jPanelListiHerbLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jButton1.setBackground(new java.awt.Color(42, 158, 197));
        jButton1.setText("Bóka herbergi");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBokaHerbergi(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(226, 226, 226)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(240, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelListiHerb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelListiHerb, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**Til baka takkinn*/
    private void jBackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBackButtonActionPerformed
        this.setVisible(false);
        vidmotHotels.setVisible(true);
    }//GEN-LAST:event_jBackButtonActionPerformed

    
    private void jButtonBokaHerbergi(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBokaHerbergi
        NotendaUppl notandi = new NotendaUppl(this);
        notandi.setVisible(true);
    }//GEN-LAST:event_jButtonBokaHerbergi

    public void synaUppl(String eftirNafn, String forNafn, String email) {
         int index = table.getSelectedRow();
                  
         BookingDB bookDB = new BookingDB(rooms.get(index),vidmotHotels.getCheckInString(),vidmotHotels.getCheckOutString(),forNafn,"",eftirNafn,email);
         Booking booking = bookDB.getBooking();
    
         BokunarUppl bookInfo = new BokunarUppl(booking.getReferenceNumber(),booking.getHotel(),booking.getRoomNumber(),
         booking.getCheckIn(),booking.getCheckOut(),booking.getFirstName(),booking.getLastName(),
         booking.getEmail(),rooms.get(index).getPrice(),booking.getRoomType());
         
         bookInfo.setVisible(true);
         rooms.remove(index);
         
         ((DefaultTableModel)table.getModel()).removeRow(index);
         
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VidmotHerbergi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VidmotHerbergi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VidmotHerbergi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VidmotHerbergi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBackButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jHausTxt;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanelListiHerb;
    // End of variables declaration//GEN-END:variables


}
