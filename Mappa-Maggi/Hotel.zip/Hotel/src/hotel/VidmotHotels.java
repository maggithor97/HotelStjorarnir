/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel;

import hs.res.*;
import hs.db.*;
import java.awt.Color;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

public class VidmotHotels extends javax.swing.JFrame {

    private VidmotLeita vidmotLeita;
    private VidmotHotels vidmotHotels;
    private final ArrayList<Hotel> hotels; //  Listi af hótelum á þessari staðssetningu.
    private final String city;
    private final String roomType;
    private final String checkInString;
    private final String checkOutString;


    /**
     * Creates new form VidmotHotels
     */
    public VidmotHotels(String city, String roomType, Date checkIn, Date checkOut, VidmotLeita vidmotLeita) {
        this.city = city;
        this.roomType = roomType;
        this.vidmotLeita = vidmotLeita;
        DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
        this.checkInString = dateFormat.format(checkIn);
        this.checkOutString = dateFormat.format(checkOut);
        initComponents();
        HotelDB hotelDB = new HotelDB(city, checkInString, checkOutString, roomType);

        this.hotels = hotelDB.getHotels();
        this.vidmotHotels = this;

    }

    /**
     * Setur textahaus með réttri staðsetningu og checkin/checkout
     * dagssetningum.
     */
    public void geraHaus() {
        jLocationTxt.setText("Hótel í " + city);
        jCheckInTxt.setText("Innritunardagur: " + this.checkInString);
        jCheckOutTxt.setText("Útritunardagur: " + this.checkOutString);
        vidmotLeita.setVisible(false);
    }

    public void teiknaListaAfHotelum() {
        int n = hotels.size();

        Object[][] hotelsObj = new Object[n][2];
        for (int i = 0; i < n; i++) {
            hotelsObj[i][0] = hotels.get(i).getName();
            hotelsObj[i][1] = hotels.get(i).getAddress();
        }

        DefaultTableModel tableModel = new DefaultTableModel();
        JTable table = new JTable(tableModel);
        table.setRowHeight(50);
        tableModel.addColumn("Nafn");
        tableModel.addColumn("Heimilisfang");
        //tableModel.in;
        for (int i = 0; i < n; i++) {
            tableModel.insertRow(i, hotelsObj[i]);
        }

        JPanel f = new JPanel();
        f.setSize(jPanelHotelList.getSize());
// Reyna teikna lista
        Color ivory = new Color(121,155,161);
        table.setOpaque(true);
        table.setFillsViewportHeight(true);
        table.setBackground(ivory);
//
      

        f.add(new JScrollPane(table));
        f.setVisible(true);
        f.setBackground(Color.decode("#DFFAFF"));

        table.getTableHeader().setBackground(ivory);
        //add(scroll1, BorderLayout.CENTER);

        
        jPanelHotelList.add(f);
        this.vidmotHotels = this;

        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                VidmotHerbergi vidmotHerb = new VidmotHerbergi(hotels.get(table.getSelectedRow()), vidmotHotels);
                vidmotHerb.setVisible(true);
                vidmotHotels.setVisible(false);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jHaus = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLocationTxt = new javax.swing.JLabel();
        jCheckOutTxt = new javax.swing.JLabel();
        jCheckInTxt = new javax.swing.JLabel();
        jPanelHotelList = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(187, 196, 239));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jHaus.setBackground(new java.awt.Color(173, 216, 230));
        jHaus.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, null, new java.awt.Color(121, 155, 161)));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Back");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLocationTxt.setText("jLabel1");

        jCheckOutTxt.setText("jLabel2");

        jCheckInTxt.setText("jLabel3");

        javax.swing.GroupLayout jHausLayout = new javax.swing.GroupLayout(jHaus);
        jHaus.setLayout(jHausLayout);
        jHausLayout.setHorizontalGroup(
            jHausLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jHausLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(91, 91, 91)
                .addComponent(jLocationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 468, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jHausLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jCheckInTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
                    .addComponent(jCheckOutTxt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jHausLayout.setVerticalGroup(
            jHausLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jHausLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jHausLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLocationTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jHausLayout.createSequentialGroup()
                        .addComponent(jCheckOutTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckInTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jPanelHotelList.setBackground(new java.awt.Color(121, 155, 161));

        javax.swing.GroupLayout jPanelHotelListLayout = new javax.swing.GroupLayout(jPanelHotelList);
        jPanelHotelList.setLayout(jPanelHotelListLayout);
        jPanelHotelListLayout.setHorizontalGroup(
            jPanelHotelListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanelHotelListLayout.setVerticalGroup(
            jPanelHotelListLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 567, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jHaus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanelHotelList, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 4, Short.MAX_VALUE)
                .addComponent(jHaus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanelHotelList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        vidmotLeita.eydaHotelsVidmot(this);
        vidmotLeita = new VidmotLeita();
        vidmotLeita.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VidmotHotels.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VidmotHotels.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VidmotHotels.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VidmotHotels.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }

        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jCheckInTxt;
    private javax.swing.JLabel jCheckOutTxt;
    private javax.swing.JPanel jHaus;
    private javax.swing.JLabel jLocationTxt;
    private javax.swing.JPanel jPanelHotelList;
    // End of variables declaration//GEN-END:variables

}
